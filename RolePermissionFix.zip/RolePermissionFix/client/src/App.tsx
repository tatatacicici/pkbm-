import { useState } from "react";
import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import LoginPage from "@/pages/LoginPage";
import AdminDashboard from "@/pages/AdminDashboard";
import GuruDashboard from "@/pages/GuruDashboard";
import PelajarDashboard from "@/pages/PelajarDashboard";
import type { User, LoginInput } from "@shared/schema";

function Router() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // TODO: Remove mock login - replace with actual API call
  const handleLogin = (credentials: LoginInput) => {
    console.log("Login with:", credentials);
    
    // Mock user data based on username
    const mockUsers: Record<string, User> = {
      admin: {
        id: "1",
        username: "admin",
        password: "admin",
        name: "Admin Kampus",
        role: "admin",
        email: "admin@kampusgratis.ac.id",
        avatar: null,
        createdAt: new Date(),
      },
      guru: {
        id: "2",
        username: "guru",
        password: "guru",
        name: "Dr. Siti Nurhaliza",
        role: "guru",
        email: "siti@kampusgratis.ac.id",
        avatar: null,
        createdAt: new Date(),
      },
      pelajar: {
        id: "3",
        username: "pelajar",
        password: "pelajar",
        name: "Ahmad Zaki",
        role: "pelajar",
        email: "zaki@kampusgratis.ac.id",
        avatar: null,
        createdAt: new Date(),
      },
    };

    const user = mockUsers[credentials.username];
    if (user && credentials.password === user.username) {
      setCurrentUser(user);
    }
  };

  const handleLogout = () => {
    console.log("Logout");
    setCurrentUser(null);
  };

  // Show login if not authenticated
  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Role-based routing
  return (
    <Switch>
      <Route path="/">
        {currentUser.role === "admin" && <Redirect to="/admin" />}
        {currentUser.role === "guru" && <Redirect to="/guru" />}
        {currentUser.role === "pelajar" && <Redirect to="/pelajar" />}
      </Route>
      
      <Route path="/admin">
        {currentUser.role === "admin" ? (
          <AdminDashboard user={currentUser} onLogout={handleLogout} />
        ) : (
          <Redirect to="/" />
        )}
      </Route>
      
      <Route path="/guru">
        {currentUser.role === "guru" ? (
          <GuruDashboard user={currentUser} onLogout={handleLogout} />
        ) : (
          <Redirect to="/" />
        )}
      </Route>
      
      <Route path="/pelajar">
        {currentUser.role === "pelajar" ? (
          <PelajarDashboard user={currentUser} onLogout={handleLogout} />
        ) : (
          <Redirect to="/" />
        )}
      </Route>

      <Route path="/admin/:rest*">
        {currentUser.role === "admin" ? (
          <AdminDashboard user={currentUser} onLogout={handleLogout} />
        ) : (
          <Redirect to="/" />
        )}
      </Route>

      <Route path="/guru/:rest*">
        {currentUser.role === "guru" ? (
          <GuruDashboard user={currentUser} onLogout={handleLogout} />
        ) : (
          <Redirect to="/" />
        )}
      </Route>

      <Route path="/pelajar/:rest*">
        {currentUser.role === "pelajar" ? (
          <PelajarDashboard user={currentUser} onLogout={handleLogout} />
        ) : (
          <Redirect to="/" />
        )}
      </Route>

      <Route>
        <Redirect to="/" />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
