import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  className?: string;
}

export default function StatCard({ title, value, icon: Icon, className }: StatCardProps) {
  return (
    <Card className={className} data-testid="card-stat">
      <CardContent className="p-6">
        <div className="flex flex-col gap-4">
          <Icon className="w-6 h-6 text-primary" data-testid="icon-stat" />
          <div>
            <div className="text-3xl font-bold" data-testid="text-stat-value">{value}</div>
            <div className="text-sm text-muted-foreground" data-testid="text-stat-title">{title}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
