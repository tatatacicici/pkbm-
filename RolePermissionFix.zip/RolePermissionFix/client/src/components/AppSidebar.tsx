import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { 
  LayoutDashboard, 
  Users, 
  BookOpen, 
  Calendar, 
  Award,
  Settings,
  GraduationCap,
  ClipboardList,
  BarChart,
} from "lucide-react";
import type { User } from "@shared/schema";
import { Link, useLocation } from "wouter";

interface AppSidebarProps {
  user: User;
}

const menuItems = {
  admin: [
    { title: "Dashboard", icon: LayoutDashboard, url: "/admin" },
    { title: "Manajemen User", icon: Users, url: "/admin/users" },
    { title: "Fakultas", icon: GraduationCap, url: "/admin/faculties" },
    { title: "Mata Kuliah", icon: BookOpen, url: "/admin/subjects" },
    { title: "Events", icon: Calendar, url: "/admin/events" },
    { title: "Laporan", icon: BarChart, url: "/admin/reports" },
  ],
  guru: [
    { title: "Dashboard", icon: LayoutDashboard, url: "/guru" },
    { title: "Kelas Saya", icon: GraduationCap, url: "/guru/classes" },
    { title: "Mata Kuliah", icon: BookOpen, url: "/guru/subjects" },
    { title: "Nilai", icon: ClipboardList, url: "/guru/grades" },
    { title: "Kalender", icon: Calendar, url: "/guru/calendar" },
  ],
  pelajar: [
    { title: "Dashboard", icon: LayoutDashboard, url: "/pelajar" },
    { title: "Mata Kuliah Saya", icon: BookOpen, url: "/pelajar/courses" },
    { title: "Tugas", icon: ClipboardList, url: "/pelajar/assignments" },
    { title: "Nilai", icon: Award, url: "/pelajar/grades" },
    { title: "Jadwal", icon: Calendar, url: "/pelajar/schedule" },
  ],
};

export default function AppSidebar({ user }: AppSidebarProps) {
  const [location] = useLocation();
  const items = menuItems[user.role] || [];

  return (
    <Sidebar>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>KampusGratis</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton asChild isActive={location === item.url}>
                    <Link href={item.url} data-testid={`link-sidebar-${item.url}`}>
                      <item.icon className="w-5 h-5" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/settings" data-testid="link-sidebar-settings">
                <Settings className="w-5 h-5" />
                <span>Pengaturan</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
