import RoleBadge from "../RoleBadge";

export default function RoleBadgeExample() {
  return (
    <div className="flex gap-4 items-center">
      <RoleBadge role="admin" />
      <RoleBadge role="guru" />
      <RoleBadge role="pelajar" />
    </div>
  );
}
