import { SidebarProvider } from "@/components/ui/sidebar";
import AppSidebar from "../AppSidebar";

export default function AppSidebarExample() {
  const mockUser = {
    id: "1",
    username: "pelajar",
    password: "",
    name: "John Doe",
    role: "pelajar" as const,
    email: "john@kampusgratis.ac.id",
    avatar: null,
    createdAt: new Date(),
  };

  const style = {
    "--sidebar-width": "16rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar user={mockUser} />
        <main className="flex-1 p-8">
          <h1 className="text-2xl font-semibold">Dashboard Content</h1>
        </main>
      </div>
    </SidebarProvider>
  );
}
