import UserDropdown from "../UserDropdown";

export default function UserDropdownExample() {
  const mockUser = {
    id: "1",
    username: "admin",
    password: "",
    name: "Admin Kampus",
    role: "admin" as const,
    email: "admin@kampusgratis.ac.id",
    avatar: null,
    createdAt: new Date(),
  };

  return (
    <div className="flex justify-end p-4">
      <UserDropdown user={mockUser} onLogout={() => console.log("Logout clicked")} />
    </div>
  );
}
