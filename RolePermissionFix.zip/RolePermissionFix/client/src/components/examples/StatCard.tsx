import StatCard from "../StatCard";
import { BookOpen } from "lucide-react";

export default function StatCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl">
      <StatCard title="Mata Kuliah Aktif" value="12" icon={BookOpen} />
      <StatCard title="Tugas Pending" value="5" icon={BookOpen} />
      <StatCard title="Nilai Rata-rata" value="85" icon={BookOpen} />
    </div>
  );
}
