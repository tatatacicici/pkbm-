import CourseCard from "../CourseCard";

export default function CourseCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl">
      <CourseCard
        code="CS101"
        title="Pengantar Ilmu Komputer"
        instructor="Dr. Ahmad Hidayat"
        progress={65}
      />
      <CourseCard
        code="MAT201"
        title="Kalkulus Lanjut"
        instructor="Prof. Siti Nurhaliza"
        progress={40}
      />
      <CourseCard
        code="FIS101"
        title="Fisika Dasar"
        instructor="Dr. Budi Santoso"
        progress={85}
      />
    </div>
  );
}
