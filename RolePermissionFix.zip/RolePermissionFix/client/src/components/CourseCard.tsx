import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";

interface CourseCardProps {
  code: string;
  title: string;
  instructor: string;
  instructorAvatar?: string;
  progress?: number;
  thumbnail?: string;
}

export default function CourseCard({
  code,
  title,
  instructor,
  instructorAvatar,
  progress = 0,
  thumbnail,
}: CourseCardProps) {
  const initials = instructor
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card className="overflow-hidden" data-testid={`card-course-${code}`}>
      {thumbnail && (
        <div className="aspect-video bg-muted">
          <img src={thumbnail} alt={title} className="w-full h-full object-cover" />
        </div>
      )}
      {!thumbnail && (
        <div className="aspect-video bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
          <div className="text-4xl font-bold text-primary">{code}</div>
        </div>
      )}
      <CardContent className="p-6">
        <Badge className="mb-2" variant="secondary" data-testid={`badge-course-code-${code}`}>
          {code}
        </Badge>
        <h3 className="text-lg font-semibold mb-4" data-testid="text-course-title">
          {title}
        </h3>
        <div className="flex items-center gap-2 mb-4">
          <Avatar className="w-8 h-8">
            <AvatarImage src={instructorAvatar} />
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <span className="text-sm" data-testid="text-instructor-name">{instructor}</span>
        </div>
        {progress > 0 && (
          <>
            <Progress value={progress} className="h-2 mb-2" />
            <p className="text-sm text-muted-foreground" data-testid="text-course-progress">
              {progress}% selesai
            </p>
          </>
        )}
      </CardContent>
      <CardFooter className="p-6 pt-0">
        <Button className="w-full" data-testid="button-continue-learning">
          Lanjutkan Belajar
        </Button>
      </CardFooter>
    </Card>
  );
}
