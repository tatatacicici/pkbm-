import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User, LogOut, Settings } from "lucide-react";
import RoleBadge from "./RoleBadge";
import type { User as UserType } from "@shared/schema";

interface UserDropdownProps {
  user: UserType;
  onLogout?: () => void;
}

export default function UserDropdown({ user, onLogout }: UserDropdownProps) {
  const initials = user.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="flex items-center gap-3 hover-elevate rounded-lg p-2" data-testid="button-user-dropdown">
        <Avatar className="w-10 h-10">
          <AvatarImage src={user.avatar || undefined} />
          <AvatarFallback>{initials}</AvatarFallback>
        </Avatar>
        <div className="hidden md:block text-left">
          <div className="text-sm font-medium" data-testid="text-user-name">{user.name}</div>
          <RoleBadge role={user.role} className="text-xs" />
        </div>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>
          <div className="flex flex-col gap-1">
            <div>{user.name}</div>
            <div className="text-xs text-muted-foreground font-normal">{user.email}</div>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem data-testid="menu-profile">
          <User className="mr-2 w-4 h-4" />
          Profil
        </DropdownMenuItem>
        <DropdownMenuItem data-testid="menu-settings">
          <Settings className="mr-2 w-4 h-4" />
          Pengaturan
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={onLogout} data-testid="menu-logout">
          <LogOut className="mr-2 w-4 h-4" />
          Keluar
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
