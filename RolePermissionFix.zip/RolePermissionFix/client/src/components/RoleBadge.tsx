import { Badge } from "@/components/ui/badge";
import { User } from "@shared/schema";

interface RoleBadgeProps {
  role: User["role"];
  className?: string;
}

const roleConfig = {
  admin: {
    label: "Admin",
    variant: "default" as const,
  },
  guru: {
    label: "Guru",
    variant: "secondary" as const,
  },
  pelajar: {
    label: "Pelajar",
    variant: "outline" as const,
  },
};

export default function RoleBadge({ role, className }: RoleBadgeProps) {
  const config = roleConfig[role];
  
  return (
    <Badge variant={config.variant} className={className} data-testid={`badge-role-${role}`}>
      {config.label}
    </Badge>
  );
}
