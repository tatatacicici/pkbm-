import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import AppSidebar from "@/components/AppSidebar";
import UserDropdown from "@/components/UserDropdown";
import StatCard from "@/components/StatCard";
import CourseCard from "@/components/CourseCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GraduationCap, ClipboardList, Users } from "lucide-react";
import type { User } from "@shared/schema";

interface GuruDashboardProps {
  user: User;
  onLogout?: () => void;
}

export default function GuruDashboard({ user, onLogout }: GuruDashboardProps) {
  const style = {
    "--sidebar-width": "16rem",
  };

  // TODO: Remove mock data
  const pendingTasks = [
    { id: 1, task: "Koreksi Tugas Kalkulus", students: 25, deadline: "Besok" },
    { id: 2, task: "Input Nilai UTS", students: 30, deadline: "2 hari lagi" },
    { id: 3, task: "Review Proposal", students: 5, deadline: "Minggu depan" },
  ];

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar user={user} />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between p-4 border-b gap-4">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <h1 className="text-2xl font-semibold flex-1">Dashboard Guru</h1>
            <UserDropdown user={user} onLogout={onLogout} />
          </header>

          <main className="flex-1 overflow-auto p-8">
            <div className="max-w-7xl mx-auto space-y-8">
              {/* Welcome Section */}
              <div>
                <h2 className="text-2xl font-semibold mb-2">
                  Selamat Datang, {user.name}
                </h2>
                <p className="text-muted-foreground">
                  Kelola kelas dan nilai mahasiswa Anda
                </p>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard title="Kelas Aktif" value="4" icon={GraduationCap} />
                <StatCard title="Total Mahasiswa" value="120" icon={Users} />
                <StatCard title="Tugas Pending" value="8" icon={ClipboardList} />
              </div>

              {/* Active Classes */}
              <div>
                <h3 className="text-xl font-semibold mb-4">Kelas Aktif</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <CourseCard
                    code="MAT201"
                    title="Kalkulus Lanjut"
                    instructor="30 Mahasiswa"
                    progress={0}
                  />
                  <CourseCard
                    code="MAT101"
                    title="Matematika Dasar"
                    instructor="35 Mahasiswa"
                    progress={0}
                  />
                  <CourseCard
                    code="STAT301"
                    title="Statistika"
                    instructor="28 Mahasiswa"
                    progress={0}
                  />
                </div>
              </div>

              {/* Pending Tasks */}
              <Card>
                <CardHeader>
                  <CardTitle>Tugas yang Perlu Diselesaikan</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {pendingTasks.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-4 rounded-lg hover-elevate border"
                      >
                        <div>
                          <div className="font-medium">{item.task}</div>
                          <div className="text-sm text-muted-foreground">
                            {item.students} mahasiswa
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {item.deadline}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
