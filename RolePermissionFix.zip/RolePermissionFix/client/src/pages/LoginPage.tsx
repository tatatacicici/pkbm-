import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, type LoginInput } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import campusHero from "@assets/generated_images/Indonesian_campus_hero_image_987f9309.png";

interface LoginPageProps {
  onLogin?: (credentials: LoginInput) => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const handleSubmit = async (data: LoginInput) => {
    setIsLoading(true);
    console.log("Login attempt:", data);
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    if (onLogin) {
      onLogin(data);
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Panel - Hero Image (Desktop Only) */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary/90 to-primary relative overflow-hidden">
        <img
          src={campusHero}
          alt="Kampus Indonesia"
          className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-30"
        />
        <div className="relative z-10 flex flex-col justify-between p-12 text-primary-foreground">
          <div>
            <h1 className="text-4xl font-bold mb-2">KampusGratis</h1>
            <p className="text-xl opacity-90">Platform Learning Management System</p>
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center backdrop-blur">
                <span className="text-2xl font-bold">50K+</span>
              </div>
              <div>
                <div className="font-semibold">Mahasiswa Aktif</div>
                <div className="text-sm opacity-75">Belajar bersama kami</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center backdrop-blur">
                <span className="text-2xl font-bold">500+</span>
              </div>
              <div>
                <div className="font-semibold">Mata Kuliah</div>
                <div className="text-sm opacity-75">Tersedia untuk dipelajari</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="flex-1 flex items-center justify-center p-4 lg:p-12 bg-background">
        <Card className="w-full max-w-md p-8">
          <div className="mb-8 text-center lg:text-left">
            <h2 className="text-3xl font-semibold mb-2">Selamat Datang Kembali</h2>
            <p className="text-muted-foreground">
              Masuk ke akun KampusGratis Anda
            </p>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Masukkan username"
                        className="h-12"
                        data-testid="input-username"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="password"
                        placeholder="Masukkan password"
                        className="h-12"
                        data-testid="input-password"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full h-12"
                disabled={isLoading}
                data-testid="button-login"
              >
                {isLoading ? "Memproses..." : "Masuk"}
              </Button>
            </form>
          </Form>

          <div className="mt-6 text-center text-sm">
            <a href="#" className="text-primary hover:underline" data-testid="link-forgot-password">
              Lupa password?
            </a>
          </div>

          <div className="mt-4 text-center text-sm text-muted-foreground">
            <p>Demo Credentials:</p>
            <p className="font-mono text-xs mt-1">
              admin/admin | guru/guru | pelajar/pelajar
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
