import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import AppSidebar from "@/components/AppSidebar";
import UserDropdown from "@/components/UserDropdown";
import StatCard from "@/components/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, BookOpen, Calendar, BarChart3 } from "lucide-react";
import type { User } from "@shared/schema";

interface AdminDashboardProps {
  user: User;
  onLogout?: () => void;
}

export default function AdminDashboard({ user, onLogout }: AdminDashboardProps) {
  const style = {
    "--sidebar-width": "16rem",
  };

  // TODO: Remove mock data
  const recentActivities = [
    { id: 1, action: "User baru terdaftar", user: "Ahmad Zaki", time: "5 menit lalu" },
    { id: 2, action: "Mata kuliah dibuat", user: "Dr. Siti", time: "1 jam lalu" },
    { id: 3, action: "Event dijadwalkan", user: "Admin", time: "2 jam lalu" },
    { id: 4, action: "Nilai diupdate", user: "Prof. Budi", time: "3 jam lalu" },
  ];

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar user={user} />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between p-4 border-b gap-4">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <h1 className="text-2xl font-semibold flex-1">Dashboard Admin</h1>
            <UserDropdown user={user} onLogout={onLogout} />
          </header>

          <main className="flex-1 overflow-auto p-8">
            <div className="max-w-7xl mx-auto space-y-8">
              {/* Welcome Section */}
              <div>
                <h2 className="text-2xl font-semibold mb-2">
                  Selamat Datang, {user.name}
                </h2>
                <p className="text-muted-foreground">
                  Overview sistem KampusGratis
                </p>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Total User" value="1,247" icon={Users} />
                <StatCard title="Mata Kuliah" value="86" icon={BookOpen} />
                <StatCard title="Events Aktif" value="12" icon={Calendar} />
                <StatCard title="Rata-rata Kehadiran" value="92%" icon={BarChart3} />
              </div>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Aktivitas Terbaru</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivities.map((activity) => (
                      <div
                        key={activity.id}
                        className="flex items-center justify-between p-4 rounded-lg hover-elevate border"
                      >
                        <div>
                          <div className="font-medium">{activity.action}</div>
                          <div className="text-sm text-muted-foreground">
                            oleh {activity.user}
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {activity.time}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
