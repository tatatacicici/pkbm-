import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import AppSidebar from "@/components/AppSidebar";
import UserDropdown from "@/components/UserDropdown";
import StatCard from "@/components/StatCard";
import CourseCard from "@/components/CourseCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, ClipboardList, Award, Calendar } from "lucide-react";
import type { User } from "@shared/schema";

interface PelajarDashboardProps {
  user: User;
  onLogout?: () => void;
}

export default function PelajarDashboard({ user, onLogout }: PelajarDashboardProps) {
  const style = {
    "--sidebar-width": "16rem",
  };

  // TODO: Remove mock data
  const upcomingDeadlines = [
    { id: 1, course: "Kalkulus Lanjut", task: "Tugas 3", deadline: "Besok, 23:59" },
    { id: 2, course: "Fisika Dasar", task: "Lab Report", deadline: "3 hari lagi" },
    { id: 3, course: "Pemrograman Web", task: "Project Akhir", deadline: "1 minggu lagi" },
  ];

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar user={user} />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between p-4 border-b gap-4">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <h1 className="text-2xl font-semibold flex-1">Dashboard Pelajar</h1>
            <UserDropdown user={user} onLogout={onLogout} />
          </header>

          <main className="flex-1 overflow-auto p-8">
            <div className="max-w-7xl mx-auto space-y-8">
              {/* Welcome Section */}
              <div>
                <h2 className="text-2xl font-semibold mb-2">
                  Selamat Datang, {user.name}
                </h2>
                <p className="text-muted-foreground">
                  Lanjutkan perjalanan belajar Anda
                </p>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <StatCard title="Mata Kuliah Aktif" value="6" icon={BookOpen} />
                <StatCard title="Tugas Pending" value="3" icon={ClipboardList} />
                <StatCard title="Kelas Hari Ini" value="2" icon={Calendar} />
                <StatCard title="IPK" value="3.85" icon={Award} />
              </div>

              {/* Enrolled Courses */}
              <div>
                <h3 className="text-xl font-semibold mb-4">Mata Kuliah Saya</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <CourseCard
                    code="MAT201"
                    title="Kalkulus Lanjut"
                    instructor="Prof. Siti Nurhaliza"
                    progress={65}
                  />
                  <CourseCard
                    code="FIS101"
                    title="Fisika Dasar"
                    instructor="Dr. Budi Santoso"
                    progress={40}
                  />
                  <CourseCard
                    code="CS301"
                    title="Pemrograman Web"
                    instructor="Dr. Ahmad Hidayat"
                    progress={75}
                  />
                </div>
              </div>

              {/* Upcoming Deadlines */}
              <Card>
                <CardHeader>
                  <CardTitle>Deadline Mendatang</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {upcomingDeadlines.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-4 rounded-lg hover-elevate border"
                      >
                        <div>
                          <div className="font-medium">{item.task}</div>
                          <div className="text-sm text-muted-foreground">
                            {item.course}
                          </div>
                        </div>
                        <div className="text-sm text-destructive font-medium">
                          {item.deadline}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
