import PelajarDashboard from "../PelajarDashboard";

export default function PelajarDashboardExample() {
  const mockUser = {
    id: "3",
    username: "pelajar",
    password: "",
    name: "Ahmad Zaki",
    role: "pelajar" as const,
    email: "zaki@kampusgratis.ac.id",
    avatar: null,
    createdAt: new Date(),
  };

  return <PelajarDashboard user={mockUser} onLogout={() => console.log("Logout")} />;
}
