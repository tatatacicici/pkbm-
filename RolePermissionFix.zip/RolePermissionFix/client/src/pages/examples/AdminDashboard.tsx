import AdminDashboard from "../AdminDashboard";

export default function AdminDashboardExample() {
  const mockUser = {
    id: "1",
    username: "admin",
    password: "",
    name: "Admin Kampus",
    role: "admin" as const,
    email: "admin@kampusgratis.ac.id",
    avatar: null,
    createdAt: new Date(),
  };

  return <AdminDashboard user={mockUser} onLogout={() => console.log("Logout")} />;
}
