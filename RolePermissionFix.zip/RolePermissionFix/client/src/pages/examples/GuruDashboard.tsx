import GuruDashboard from "../GuruDashboard";

export default function GuruDashboardExample() {
  const mockUser = {
    id: "2",
    username: "guru",
    password: "",
    name: "Dr. Siti Nurhaliza",
    role: "guru" as const,
    email: "siti@kampusgratis.ac.id",
    avatar: null,
    createdAt: new Date(),
  };

  return <GuruDashboard user={mockUser} onLogout={() => console.log("Logout")} />;
}
