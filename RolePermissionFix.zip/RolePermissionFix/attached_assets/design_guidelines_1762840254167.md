# Design Guidelines: LMS Campus Authentication System

## Design Approach

**Selected Approach:** Design System + Educational Platform Reference  
**Primary References:** Canvas LMS, Google Classroom, Notion (for clean information architecture)  
**Justification:** Educational platforms require clarity, trust, and accessibility while maintaining modern aesthetics. The system must prioritize usability for diverse user groups (students, instructors, administrators).

## Core Design Principles

1. **Clarity First:** Clear visual hierarchy guides users through authentication flows
2. **Trust & Security:** Professional appearance reinforces security confidence
3. **Accessibility:** WCAG 2.1 AA compliance throughout
4. **Responsive Excellence:** Seamless experience across all devices

---

## Typography System

### Font Families
- **Primary:** Inter (via Google Fonts CDN)
- **Headings:** Inter, weight 600-700
- **Body:** Inter, weight 400-500
- **Accents:** Inter, weight 500

### Type Scale
- **Hero/H1:** text-4xl md:text-5xl, font-semibold, leading-tight
- **H2:** text-3xl md:text-4xl, font-semibold
- **H3:** text-2xl, font-semibold
- **H4:** text-xl, font-medium
- **Body Large:** text-lg, font-normal
- **Body:** text-base, font-normal
- **Small:** text-sm, font-normal
- **Micro:** text-xs, font-medium

---

## Layout System

### Spacing Primitives
**Core Units:** 2, 4, 6, 8, 12, 16, 20, 24  
**Usage Pattern:**
- Micro spacing: p-2, gap-2 (8px)
- Standard spacing: p-4, gap-4, m-4 (16px)
- Section spacing: p-6, py-8 (24px, 32px)
- Large spacing: p-12, py-16, py-20 (48px, 64px, 80px)
- Extra large: py-24 (96px)

### Grid System
- **Container:** max-w-7xl mx-auto px-4 md:px-6 lg:px-8
- **Content Width:** max-w-md for forms, max-w-4xl for dashboards
- **Breakpoints:** sm (640px), md (768px), lg (1024px), xl (1280px)

---

## Page-Specific Design

### Login Page

**Layout Structure:**
- Full viewport height with centered content (min-h-screen flex items-center justify-center)
- Split-screen design on desktop (lg:grid lg:grid-cols-2)
- Left panel: Branding and educational imagery
- Right panel: Authentication form

**Left Panel (Desktop Only):**
- Full height with subtle gradient overlay
- University/institution logo at top (p-8)
- Large hero image showcasing campus or students learning
- Overlay text: Institution name (text-4xl font-bold) and tagline (text-xl)
- Statistics or trust indicators at bottom (p-8): "Join 50,000+ Students" style badges

**Right Panel (Form Container):**
- Centered card: max-w-md mx-auto px-6 py-12
- Logo/brand mark at top (mb-8)
- Heading: "Welcome Back" (text-3xl font-semibold mb-2)
- Subheading: "Sign in to access your courses" (text-base mb-8)
- Form spacing: space-y-6
- Input fields: h-12, rounded-lg, px-4, text-base
- Labels: text-sm font-medium mb-2
- Primary CTA button: w-full h-12 rounded-lg font-medium text-base
- Footer links: "Forgot password?" and "Need help?" (text-sm, mt-6)

**Mobile Adaptation:**
- Single column layout
- Minimal header with logo (py-6)
- Form in card container with slight shadow
- Padding: px-4 py-8

### Dashboard Page

**Navigation Structure:**
- Top navbar: h-16, fixed top-0, w-full, z-50
- Logo/institution name (left)
- Main navigation items (center on desktop)
- User profile dropdown (right): avatar + name + role badge
- Mobile: Hamburger menu icon

**Sidebar (Desktop):**
- Fixed left sidebar: w-64, min-h-screen
- Navigation items: p-4, rounded-lg, mb-2
- Icons from Heroicons (outline style): 20x20 size
- Active state: distinct background
- Sections: Dashboard, My Courses, Assignments, Grades, Calendar
- Logout at bottom

**Main Content Area:**
- Margin for sidebar: lg:ml-64
- Padding top for fixed navbar: pt-16
- Container: max-w-7xl mx-auto px-4 py-8
- Grid layout for cards: grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6

**Dashboard Components:**

1. **Welcome Header:**
   - Full width section (mb-8)
   - Greeting: "Welcome back, [Name]" (text-2xl font-semibold)
   - Role badge and last login info (text-sm)

2. **Stats Cards Row:**
   - Grid: grid-cols-1 md:grid-cols-4 gap-4 (mb-8)
   - Card structure: p-6, rounded-xl, shadow-sm
   - Icon at top (mb-4, size 24x24)
   - Value: text-3xl font-bold
   - Label: text-sm
   - Metrics: Active Courses, Pending Assignments, Upcoming Classes, Grade Average

3. **Active Courses Section:**
   - Section heading: text-xl font-semibold (mb-4)
   - Grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
   - Course card structure:
     - Course thumbnail image (aspect-video, rounded-t-xl)
     - Card body (p-6):
       - Course code badge (text-xs, px-3 py-1, rounded-full, mb-2)
       - Course title (text-lg font-semibold, mb-2)
       - Instructor name with avatar (flex items-center gap-2, mb-4)
       - Progress bar (h-2, rounded-full, mb-2)
       - Progress text (text-sm)
       - CTA: "Continue Learning" button (w-full, mt-4)

4. **Recent Activity Feed:**
   - Right sidebar on xl screens (xl:col-span-1)
   - Full width section on smaller screens (mb-8)
   - Heading: "Recent Activity" (text-lg font-semibold, mb-4)
   - Activity items (space-y-4):
     - Flex layout with icon, content, timestamp
     - Icon: 16x16 in circle container (w-8 h-8)
     - Text: Action description (text-sm)
     - Time: Relative time (text-xs)

5. **Upcoming Deadlines:**
   - Section heading (mb-4)
   - List layout (space-y-3):
     - Card: p-4, rounded-lg, flex justify-between items-center
     - Left: Assignment name (font-medium), course (text-sm)
     - Right: Due date badge, urgency indicator

---

## Component Library

### Buttons
- **Primary:** h-12, px-6, rounded-lg, font-medium, text-base, shadow-sm
- **Secondary:** h-12, px-6, rounded-lg, font-medium, text-base, border-2
- **Icon Buttons:** w-10 h-10, rounded-lg, flex items-center justify-center

### Form Inputs
- **Text Input:** h-12, px-4, rounded-lg, text-base, border-2, w-full
- **Focus State:** ring-4, ring-opacity-20
- **Error State:** border-error, with text-sm error message (mt-1)
- **Label:** text-sm, font-medium, mb-2, block

### Cards
- **Standard:** p-6, rounded-xl, shadow-sm
- **Interactive:** hover:shadow-md transition-shadow duration-200
- **With Image:** overflow-hidden, rounded-xl

### Badges
- **Status:** px-3 py-1, text-xs font-medium, rounded-full
- **Role:** px-2 py-0.5, text-xs font-semibold, rounded

### Avatars
- **Small:** w-8 h-8, rounded-full
- **Medium:** w-10 h-10, rounded-full
- **Large:** w-16 h-16, rounded-full
- All with object-cover and default initials fallback

### Icons
- **Library:** Heroicons (outline for navigation, solid for emphasis)
- **Sizes:** 16x16 (small), 20x20 (standard), 24x24 (prominent)
- **Usage:** Inline with text (align using flex items-center gap-2)

---

## Images

### Login Page Hero Image
- **Placement:** Left panel (desktop only), full height
- **Description:** High-quality image of campus environment, students collaborating, or modern learning space with natural lighting
- **Treatment:** Subtle gradient overlay for text legibility
- **Fallback:** Institution brand pattern on mobile

### Course Thumbnails
- **Aspect Ratio:** 16:9 (aspect-video class)
- **Placement:** Top of course cards
- **Description:** Subject-relevant imagery or course-specific graphics
- **Default:** Branded placeholder with course code

### User Avatars
- **Placement:** Navigation header, activity feed, instructor attribution
- **Fallback:** Colored circle with user initials

---

## Responsive Behavior

### Mobile (< 768px)
- Single column layouts
- Hamburger navigation
- Stacked stats cards
- Full-width form inputs
- Bottom sheet for filters/actions

### Tablet (768px - 1024px)
- 2-column course grid
- Condensed sidebar (collapsible)
- Stats in 2x2 grid

### Desktop (> 1024px)
- Full sidebar navigation (always visible)
- 3-column course grid
- Multi-column dashboard layout
- Hover interactions enabled

---

## Animation Guidelines

**Minimal, Purposeful Motion:**
- Page transitions: None (instant navigation)
- Hover states: Simple opacity/shadow changes (duration-200)
- Dropdown menus: Subtle slide-down (duration-150)
- Loading states: Skeleton screens (no spinners)
- Notifications: Slide-in from top (duration-300)

**No Animations For:**
- Scrolling effects
- Parallax
- Complex page transitions
- Decorative motion

---

## Accessibility Requirements

- All interactive elements: min-height 44px (touch target)
- Focus indicators: Visible 4px ring offset
- Form validation: Both visual and text feedback
- Skip navigation link: For keyboard users
- ARIA labels: On all icon-only buttons
- Semantic HTML: Proper heading hierarchy
- Contrast ratios: Minimum 4.5:1 for text

This design system creates a professional, trustworthy LMS experience that prioritizes user efficiency while maintaining visual appeal appropriate for an educational institution.