import { db } from "./db";
import { users } from "@shared/schema";
import bcrypt from "bcryptjs";

async function seed() {
  console.log("🌱 Seeding database...");

  try {
    // Hash passwords
    const hashedAdminPassword = await bcrypt.hash("admin", 10);
    const hashedGuruPassword = await bcrypt.hash("guru", 10);
    const hashedPelajarPassword = await bcrypt.hash("pelajar", 10);

    // Insert seed users
    const seedUsers = [
      {
        username: "admin",
        password: hashedAdminPassword,
        name: "Admin Kampus",
        role: "admin" as const,
        email: "admin@kampusgratis.ac.id",
      },
      {
        username: "guru",
        password: hashedGuruPassword,
        name: "Dr. Siti Nurhaliza",
        role: "guru" as const,
        email: "siti@kampusgratis.ac.id",
      },
      {
        username: "pelajar",
        password: hashedPelajarPassword,
        name: "Ahmad Zaki",
        role: "pelajar" as const,
        email: "zaki@kampusgratis.ac.id",
      },
    ];

    for (const user of seedUsers) {
      await db.insert(users).values(user).onConflictDoNothing();
      console.log(`✓ Created user: ${user.username} (${user.role})`);
    }

    console.log("✅ Seeding completed!");
  } catch (error) {
    console.error("❌ Seeding failed:", error);
    throw error;
  }
}

seed()
  .then(() => {
    console.log("Done!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Fatal error:", error);
    process.exit(1);
  });
